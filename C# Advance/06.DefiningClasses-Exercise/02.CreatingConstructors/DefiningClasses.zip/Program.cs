﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            Person firstPerson = new Person() { Name = "Rado", Age = 31 };
            Person secondPerson = new Person() { Name = "Viki", Age = 31 };
            Person thirdPerson = new Person() { Name = "Krasimira", Age = 53 };

            

        }
    }
}
