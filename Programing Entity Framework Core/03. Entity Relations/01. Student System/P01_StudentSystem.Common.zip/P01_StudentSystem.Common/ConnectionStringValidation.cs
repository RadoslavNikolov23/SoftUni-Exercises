﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Common
{
    public static class ConnectionStringValidation
    {
        public const string StringConnectionAddress = "Server=RADO\\RMSSQLSERVER;Database=StudentSystem;Trusted_Connection=True;";

    }
}
