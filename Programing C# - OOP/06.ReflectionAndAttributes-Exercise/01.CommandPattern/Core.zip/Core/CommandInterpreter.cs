﻿using CommandPattern.Core.Commands;
using CommandPattern.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CommandPattern.Core
{
    public class CommandInterpreter : ICommandInterpreter
    {
        public string Read(string args)
        {
            string[] array= args.Split(" ",StringSplitOptions.RemoveEmptyEntries);
            string commandName= array[0];
            string[] commandsArgs=array.Skip(1).ToArray();

           // ICommand command = null;
            Type typeCM=Assembly.GetEntryAssembly().GetTypes().First(x=>x.Name==$"{commandName}Command");
        

            if(typeCM == null) throw new InvalidOperationException("Wrong command!");

            ICommand mycom = (ICommand)Activator.CreateInstance(typeCM);
            return mycom.Execute(commandsArgs);


            //if (commandName == "Hello")
            //{
            //    command=new HelloCommand();
            //}
            //else if(commandName == "Exit")
            //{
            //    command = new ExitCommand();
            //}
            //else
            //{
            //    throw new InvalidOperationException("No such command exists!");
            //}

            //return command.Execute(commandsArgs);
        }
    }
}
